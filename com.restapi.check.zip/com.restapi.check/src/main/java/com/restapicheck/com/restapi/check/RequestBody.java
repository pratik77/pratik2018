package com.restapicheck.com.restapi.check;


public class RequestBody {
    String firstName;
    String lastName;
    String text;
}
