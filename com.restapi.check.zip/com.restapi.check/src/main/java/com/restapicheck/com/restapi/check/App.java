package com.restapicheck.com.restapi.check;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.web.client.RestTemplate;

/**
 * Hello world!
 *
 */
public class App implements CommandLineRunner
{
	public static void main(String args[]) {
	    SpringApplication.run(App.class);
	    
	  }
	
	public void run(String... args) throws Exception {
	    RestTemplate restTemplate = new RestTemplate();
	    Response response = restTemplate.getForObject(
	                           "http://services.groupkt.com/country/get/iso2code/IN",
	                            Response.class);
	    
	    
	    System.out.println(response.getRestResponse().getResult().getName());
}
}
