package com.cg.tourist.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.tourist.dao.TouristDAO;
import com.cg.tourist.dto.Place;
import com.cg.tourist.dto.User;
import com.cg.tourist.staticDB.StaticDB;


@Controller
public class TouristController {
	TouristDAO dao = new TouristDAO();

	String userId="";
	String userFlag;
	String search="";
	User userGlobal;
	String message="";
	int pageSize=3;
	int j;
	int currPage=0;
	ArrayList searchPlace=new ArrayList();


	private List allPlacesUser(Model model)
	{
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		List<Place> values = new ArrayList();
		userId = "Welcome "+userGlobal.getFirstName()+" "+userGlobal.getLastName();
		for(String tag:userGlobal.getTags())
		{
			Iterator it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			if(placeTemp.getTags().equals(tag))
			{
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
			}
			}
			System.out.println(tag);
		}
		
	return values;
	}
	@RequestMapping(value = "/loginPage.obj")
	public String loginPage(Model model)
	{
		model.addAttribute("user",new User());
		model.addAttribute("tags",StaticDB.getTags());
		return "login";
	}
	@RequestMapping(value = "/login.obj")
	public String checkLogin(@RequestParam("username") String username,
			@RequestParam("password") String password, Model model) {

		userGlobal = dao.checkLogin(username, password);
		userId="";
		System.out.println(userGlobal.getUsername());
		model.addAttribute("userId", userId);
		if (userGlobal.getUsername()==null)
		{
			message="Invalid user ID and password combination.";
			model.addAttribute("message",message
					);
			message="";
			model.addAttribute("user",new User());
			model.addAttribute("tags",StaticDB.getTags());
		return "login";
		}
		else if(userGlobal.getUserFlag()==1)
		{
			HashMap<String, Place> places = new HashMap();
			places = dao.retrieveAllPlaces();
			Set set = places.entrySet();
			Iterator it = set.iterator();
			List<Place> values = new ArrayList();
			userId = "Welcome "+userGlobal.getFirstName()+" "+userGlobal.getLastName();
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				Place placeTemp = new Place();
				placeTemp = me.getValue();
				values.add(placeTemp);
				System.out.println(placeTemp.getName());
			}
			if(values.size()%3!=0)
				j=(values.size()/pageSize)+1;
			else
				j=values.size()/pageSize;
			model.addAttribute("currPage", currPage);
			model.addAttribute("j", j);
			model.addAttribute("places", values);
			model.addAttribute("place", new Place());
			model.addAttribute("userId", userId);
			return "allPlaces";
		}
		else
		{
			if(searchPlace.size()!=0)
				searchPlace.clear();
			HashMap<String, Place> places = new HashMap();
			places = dao.retrieveAllPlaces();
			Set set = places.entrySet();
			//List<Place> values = new ArrayList();
			userId = "Welcome "+userGlobal.getFirstName()+" "+userGlobal.getLastName();
			for(String tag:userGlobal.getTags())
			{
				Iterator it = set.iterator();
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				Place placeTemp = new Place();
				placeTemp = me.getValue();
				if(placeTemp.getTags().equals(tag))
				{
					searchPlace.add(placeTemp);
				System.out.println(placeTemp.getName());
				}
				}
				System.out.println(tag);
			}
			if(searchPlace.size()%3!=0)
				j=(searchPlace.size()/pageSize)+1;
			else
				j=searchPlace.size()/pageSize;
			model.addAttribute("currPage", currPage);
			model.addAttribute("j", j);
			model.addAttribute("places", searchPlace);
			model.addAttribute("place", new Place());
			model.addAttribute("userId", userId);
		return "allPlacesUser";
		}
	}
	
	@RequestMapping(value = "/createAnAccount.obj")
	public String createAnAccount(Model model) {
		return "createAnAccount";
	}

	@RequestMapping(value = "/retrieveAllPlaces.obj")
	public String retrieveAllPlaces(Model model) {
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		Iterator it = set.iterator();
		@SuppressWarnings("rawtypes")
		List<Place> values = new ArrayList();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		if(values.size()%3!=0)
			j=(values.size()/pageSize)+1;
		else
			j=values.size()/pageSize;
		model.addAttribute("currPage", currPage);
		model.addAttribute("j", j);
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		if(userGlobal.getUserFlag()==1)
		return "allPlaces";
		if(searchPlace.size()!=0)
			searchPlace.clear();
		places = new HashMap();
		places = dao.retrieveAllPlaces();
		set = places.entrySet();
		//values = new ArrayList();
		
		for(String tag:userGlobal.getTags())
		{
			it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			if(placeTemp.getTags().equals(tag))
			{
				searchPlace.add(placeTemp);
			System.out.println(placeTemp.getName());
			}
			}
			System.out.println(tag);
		}
		if(values.size()%3!=0)
			j=(values.size()/pageSize)+1;
		else
			j=values.size()/pageSize;
		model.addAttribute("j", j);
		model.addAttribute("currPage", currPage);
		model.addAttribute("places", searchPlace);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		return "allPlacesUser";

	}

	@RequestMapping(value = "/modifyOrDelete.obj")
	public String modifyAndDeletePlace(@RequestParam("submit") String submit,
			@RequestParam("placeObj") String name, Model model) {
		
		Place place=new Place();
		if (("modify").equals(submit)) {
			try {
				
				place.setName(name);
				place = dao.getPlaceByName(place.getName());
				
			} catch (Exception e) {
				model.addAttribute("message", e.getMessage());
				return "error";
			}
			model.addAttribute("place", place);
			model.addAttribute("areas",StaticDB.getAreas());
			model.addAttribute("userId", userId);
			return "modifyPlace";
		}
		else{
		List<Place> values = new ArrayList();
		String key="";
		try {
			HashMap temphm=new HashMap();
			temphm=StaticDB.getPlaces();
			Set set=temphm.entrySet();
			Iterator it = set.iterator();
			
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				if(me.getValue().getName().equals(name))
				{
				//StaticDB.getPlaces().remove(me.getKey());
					key=me.getKey();
				}
				else
				{
					Place placeTemp=new Place();
					placeTemp=me.getValue();
					values.add(placeTemp);
				}
			}
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		if(values.size()%3!=0)
			j=(values.size()/pageSize)+1;
		else
			j=values.size()/pageSize;
		model.addAttribute("j", j);
		model.addAttribute("currPage", currPage);
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		StaticDB.getPlaces().remove(key);
		return "allPlaces";
		

		
	}
	}

	@RequestMapping(value = "/insertModifiedPlace.obj", method = RequestMethod.POST)
	public String insertModifiedPlace(@ModelAttribute("place") Place place,
			Model model) {
		
		//System.out.println(place.getAddress());
		try {
			dao.updatePlace(place);
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		Iterator it = set.iterator();
		List<Place> values = new ArrayList();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		if(values.size()%3!=0)
			j=(values.size()/pageSize)+1;
		else
			j=values.size()/pageSize;
		model.addAttribute("currPage", currPage);
		model.addAttribute("j", j);
		model.addAttribute("places", values);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		//if(userGlobal.getUserFlag()==1)
		return "allPlaces";
	}

	@RequestMapping(value = "/addPlace.obj")
	public String addPlace(Model model) {
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		model.addAttribute("areas",StaticDB.getAreas());
		return "addPlace";
	}

	@RequestMapping(value = "/insertPlace.obj", method = RequestMethod.POST)
	public String insertPlace(@ModelAttribute("place") Place place, Model model) {
		try {
			Place placeTemp = dao.insertPlace(place);
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		model.addAttribute("message", "Place with name " + place.getName()
				+ " added successfully!");
		model.addAttribute("userId", userId);
		return "successPlace";
	}
	
	@RequestMapping(value = "/searchPlace.obj", method = RequestMethod.POST)
	public String searchPlace(@RequestParam("place") String place, Model model) {
		if(searchPlace.size()!=0)
		searchPlace.clear();
		try {
			Set set=StaticDB.getPlaces().entrySet();
			Iterator it = set.iterator();
			
			while (it.hasNext()) {
				Map.Entry<String, Place> me = (Map.Entry) it.next();
				int flag=0;
				if(me.getValue().getName().length()>=place.length())
				{
				for(int i=0;i<place.length();i++)
				{
					if(place.toLowerCase().charAt(i)==me.getValue().getName().toLowerCase().charAt(i))
						continue;
					else 
					{
						flag=1;
						break;
					}
				}}
				else flag=1;
				if(flag==0)
				{
					Place placeTemp=new Place();
					placeTemp=me.getValue();
					searchPlace.add(placeTemp);
					}
				
				/*if(me.getValue().getName().toLowerCase().contains(place.toLowerCase()))
				{
				Place placeTemp=new Place();
				placeTemp=me.getValue();
				values.add(placeTemp);
				}*/
			}
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}
		
		search=place;
		model.addAttribute("search",search);
		search="";
		if(searchPlace.size()%3!=0)
			j=(searchPlace.size()/pageSize)+1;
		else
			j=searchPlace.size()/pageSize;
		model.addAttribute("currPage", currPage);
		model.addAttribute("j", j);
		model.addAttribute("places", searchPlace);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		
		if(userGlobal.getUserFlag()==1)
			return "searchMenu";
		if(searchPlace.size()!=0)
			searchPlace.clear();
		//List<Place> valueTemp = new ArrayList();
		searchPlace=(ArrayList) searchForUser(place);
		if(searchPlace.size()%3!=0)
			j=(searchPlace.size()/pageSize)+1;
		else
			j=searchPlace.size()/pageSize;
		model.addAttribute("currPage", currPage);
		model.addAttribute("j", j);
		model.addAttribute("places", searchPlace);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
			return "searchMenuUser";
	}
	
	@RequestMapping(value = "/addUser.obj")
	public String artistSongAssoc(@ModelAttribute("user") User user,
			@RequestParam("tagSelect") String[] tags, Model model) {

			Set<String> username=StaticDB.getUser().keySet();
			for(String usernameCheck:username)
			{
				if(usernameCheck.equals(user.getUsername()))
				{
					model.addAttribute("message",
							"Hey "+user.getFirstName()+"! username already taken.!");
					model.addAttribute("user",new User());
					model.addAttribute("tags",StaticDB.getTags());
					return "login";
				}
			}
			user.setUserFlag(2);
			for(String tag:tags)
			{
				user.getTags().add(tag);
				System.out.println(tag);
			}
		/*} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			return "error";
		}*/
		StaticDB.getUser().put(user.getUsername(), user);
		model.addAttribute("message",
				"Hey "+user.getFirstName()+"! you are registered successfully!");
		model.addAttribute("tags",StaticDB.getTags());
		model.addAttribute("user",new User());
		return "login";
	}
	
	private List searchForUser(String place)
	{
		HashMap<String, Place> places = new HashMap();
		places = dao.retrieveAllPlaces();
		Set set = places.entrySet();
		Set<Place> values = new HashSet();
		
		for(String tag:userGlobal.getTags())
		{
			Iterator it = set.iterator();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			if(placeTemp.getTags().equals(tag))
			{
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
			}
			}
			System.out.println(tag);
		}
		List<Place> valueTemp = new ArrayList();
		for(Place placeTemp:values)
		{
			int flag=0;
			if(placeTemp.getName().length()>=place.length())
			{
			for(int i=0;i<place.length();i++)
			{
				System.out.println(place.toLowerCase().charAt(i));
				if(place.toLowerCase().charAt(i)==placeTemp.getName().toLowerCase().charAt(i))
					continue;
				else 
				{
					flag=1;
					break;
				}
			}}
			else flag=1;
			if(flag==0)
			{
				Place placeIns=new Place();
				placeIns=placeTemp;
				valueTemp.add(placeTemp);
				}
		}
			return valueTemp;
	}
	
	@RequestMapping(value = "/submitFeedback.obj")
	public String submitFeedback(Model model)
	{
		model.addAttribute("userId", userId);
		return "submitFeedback";
	}
	@RequestMapping(value = "/addFeedback.obj")
	public String addFeedback(@RequestParam("textarea")String textarea,Model model)
	{
		StaticDB.feedbacks.add(textarea);
		List values;
		if(searchPlace.size()!=0)
			searchPlace.clear();
		searchPlace=(ArrayList) allPlacesUser(model);
		userId = "Welcome "+userGlobal.getFirstName()+" "+userGlobal.getLastName();
		if(searchPlace.size()%3!=0)
			j=(searchPlace.size()/pageSize)+1;
		else
			j=searchPlace.size()/pageSize;
		model.addAttribute("j", j);
		model.addAttribute("currPage", currPage);
		model.addAttribute("places", searchPlace);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		return "allPlacesUser";
	}
	
	@RequestMapping(value = "/showFeedbacks.obj")
	public String showFeedbacks(Model model)
	{
		userId = "Welcome "+userGlobal.getFirstName()+" "+userGlobal.getLastName();
		model.addAttribute("userId", userId);
		model.addAttribute("feedbacks",StaticDB.getFeedbacks());
		return "showFeedbacks";
	}
	
	@RequestMapping(value = "/pagination.obj")
	public String pagination(@RequestParam("i")int i,Model model)
	{
		Set set = StaticDB.getPlaces().entrySet();
		Iterator it = set.iterator();
		List<Place> values = new ArrayList();
		List<Place> valuesPage = new ArrayList();
		while (it.hasNext()) {
			Map.Entry<String, Place> me = (Map.Entry) it.next();
			Place placeTemp = new Place();
			placeTemp = me.getValue();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		int j;
		for(j=i*3;j<i*3+3;j++)
		{
			try{
				valuesPage.add(values.get(j));
			}catch(Exception e)
			{
				int size;
				if(values.size()%3!=0)
					size=(values.size()/pageSize)+1;
				else
					size=values.size()/pageSize;
				model.addAttribute("currPage", i);
				model.addAttribute("j", size);
				model.addAttribute("places", valuesPage);
				model.addAttribute("place", new Place());
				model.addAttribute("userId", userId);
				//if(userGlobal.getUserFlag()==1)
				return "allPlaces";
			}
		}
		int size;
		if(values.size()%3!=0)
			size=(values.size()/pageSize)+1;
		else
			size=values.size()/pageSize;
		
		model.addAttribute("currPage", i);
		model.addAttribute("j", size);
		model.addAttribute("places", valuesPage);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		//if(userGlobal.getUserFlag()==1)
		return "allPlaces";
	}
	
	@RequestMapping(value = "/paginationSearch.obj")
	public String paginationSearch(@RequestParam("i")int i,Model model)
	{
		
		Iterator it = searchPlace.iterator();
		List<Place> values = new ArrayList();
		List<Place> valuesPage = new ArrayList();
		while (it.hasNext()) {
			Place placeTemp = new Place();
			placeTemp = (Place) it.next();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		
	
		int j;
		for(j=i*3;j<i*3+3;j++)
		{
			try{
				valuesPage.add(values.get(j));
			}catch(Exception e)
			{
				int size;
				if(values.size()%3!=0)
					size=(values.size()/pageSize)+1;
				else
					size=values.size()/pageSize;
				model.addAttribute("currPage", i);
				model.addAttribute("j", size);
				model.addAttribute("places", valuesPage);
				model.addAttribute("place", new Place());
				model.addAttribute("userId", userId);
				//if(userGlobal.getUserFlag()==1)
				return "searchMenu";
			}
		}
		int size;
		if(values.size()%3!=0)
			size=(values.size()/pageSize)+1;
		else
			size=values.size()/pageSize;
		
		model.addAttribute("currPage", i);
		model.addAttribute("j", size);
		model.addAttribute("places", valuesPage);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		//if(userGlobal.getUserFlag()==1)
		return "searchMenu";
	}
	
	@RequestMapping(value = "/paginationUser.obj")
	public String paginationUser(@RequestParam("i")int i,Model model)
	{
		
		Iterator it = searchPlace.iterator();
		List<Place> values = new ArrayList();
		List<Place> valuesPage = new ArrayList();
		while (it.hasNext()) {
			Place placeTemp = new Place();
			placeTemp = (Place) it.next();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		
	
		int j;
		for(j=i*3;j<i*3+3;j++)
		{
			try{
				valuesPage.add(values.get(j));
			}catch(Exception e)
			{
				int size;
				if(values.size()%3!=0)
					size=(values.size()/pageSize)+1;
				else
					size=values.size()/pageSize;
				model.addAttribute("currPage", i);
				model.addAttribute("j", size);
				model.addAttribute("places", valuesPage);
				model.addAttribute("place", new Place());
				model.addAttribute("userId", userId);
				//if(userGlobal.getUserFlag()==1)
				return "allPlacesUser";
			}
		}
		int size;
		if(values.size()%3!=0)
			size=(values.size()/pageSize)+1;
		else
			size=values.size()/pageSize;
		
		model.addAttribute("currPage", i);
		model.addAttribute("j", size);
		model.addAttribute("places", valuesPage);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		//if(userGlobal.getUserFlag()==1)
		return "allPlacesUser";
	}
	
	@RequestMapping(value = "/paginationUserSearch.obj")
	public String paginationUserSearch(@RequestParam("i")int i,Model model)
	{
		
		Iterator it = searchPlace.iterator();
		List<Place> values = new ArrayList();
		List<Place> valuesPage = new ArrayList();
		while (it.hasNext()) {
			Place placeTemp = new Place();
			placeTemp = (Place) it.next();
			values.add(placeTemp);
			System.out.println(placeTemp.getName());
		}
		
	
		int j;
		for(j=i*3;j<i*3+3;j++)
		{
			try{
				valuesPage.add(values.get(j));
			}catch(Exception e)
			{
				int size;
				if(values.size()%3!=0)
					size=(values.size()/pageSize)+1;
				else
					size=values.size()/pageSize;
				model.addAttribute("currPage", i);
				model.addAttribute("j", size);
				model.addAttribute("places", valuesPage);
				model.addAttribute("place", new Place());
				model.addAttribute("userId", userId);
				//if(userGlobal.getUserFlag()==1)
				return "searchMenuUser";
			}
		}
		int size;
		if(values.size()%3!=0)
			size=(values.size()/pageSize)+1;
		else
			size=values.size()/pageSize;
		
		model.addAttribute("currPage", i);
		model.addAttribute("j", size);
		model.addAttribute("places", valuesPage);
		model.addAttribute("place", new Place());
		model.addAttribute("userId", userId);
		//if(userGlobal.getUserFlag()==1)
		return "searchMenuUser";
	}
	
}
