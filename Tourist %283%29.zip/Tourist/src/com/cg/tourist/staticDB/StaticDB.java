package com.cg.tourist.staticDB;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.tourist.dto.Place;
import com.cg.tourist.dto.User;

public class StaticDB {
	public static HashMap<String,Place> places=new HashMap();
	public static HashMap<String,User> user=new HashMap<String,User>();
	public static ArrayList<String>areas=new ArrayList();
	public static ArrayList<String>tags=new ArrayList<String>();
	public static ArrayList<String>feedbacks=new ArrayList<String>();
	
	static{
		Place place1=new Place();
		Place place2=new Place();
		Place place3=new Place();
		Place place4=new Place();
		
		User user1=new User();
		User user2=new User();
		
		place1.setName("Shaniwar Wada");
		place1.setAddressLine1("Shivaji Nagar");
		place1.setAddressLine2("near Pune station");
		place1.setCity("Pune");
		place1.setCountry("India");
		place1.setState("Maharashtra");
		place1.setPincode("410225");
		place1.setDescription("This place is located in Pune in the state of Maharashtra/India");
		place1.setLatitude("31E 22W");
		place1.setLongitude("21N 15S");
		place1.setTags("Fort");
		
		place2.setName("Mumbai Marine Drive");
		place2.setAddressLine1("marine drive");
		place2.setAddressLine2("near churchgate station.");
		place2.setCity("Mumbai");
		place2.setCountry("India");
		place2.setState("Maharashtra");
		place2.setPincode("400023");
		place2.setDescription("This place is located in Mumbai in the state of Maharashtra/India");
		place2.setLatitude("34E 21W");
		place2.setLongitude("20N 12S");
		place2.setTags("Beach");
		
		place3.setName("Statue of liberty");
		place3.setAddressLine1("near ratataoule beach");
		place3.setAddressLine2("new york city drive");
		place3.setCity("New York City");
		place3.setCountry("United States");
		place3.setState("New York");
		place3.setPincode("11025");
		place3.setDescription("This place is located in New York City in the state of New York/US");
		place3.setLatitude("75E 22W");
		place3.setLongitude("25N 20S");
		place3.setTags("Monument");
		
		place4.setName("Taj Mahal");
		place4.setAddressLine1("gahlot nagar");
		place4.setAddressLine2("opposite agra fort");
		place4.setCity("Agra");
		place4.setCountry("India");
		place4.setState("Uttar Pradesh");
		place4.setPincode("225648");
		place4.setDescription("This place is located in Agra in the state of Uttar Pradesh/India");
		place4.setLatitude("29E 12W");
		place4.setLongitude("11N 14S");
		place4.setTags("Monument");
		
		user1.setUsername("pratik");
		user1.setPassword("zyrus");
		user1.setFirstName("Pratik");
		user1.setLastName("Sahoo");
		user1.setUserFlag(1);
		
		user2.setUsername("shuvam");
		user2.setPassword("12345");
		user2.setUserFlag(2);
		
		places.put("shaniwarWada",place1);
		places.put("mumMarineDrive",place2);
		places.put("statueOfLiberty",place3);
		places.put("tajMahal",place4);
		
		user.put("pratik", user1);
		user.put("shuvam", user2);
		
		areas.add("India");
		areas.add("United States");
		
		tags.add("Monument");
		tags.add("Beach");
		tags.add("Fort");
	}

	public static HashMap<String, Place> getPlaces() {
		return places;
	}

	public static void setPlaces(HashMap<String, Place> places) {
		StaticDB.places = places;
	}

	public static HashMap<String, User> getUser() {
		return user;
	}

	public static void setUser(HashMap<String, User> user) {
		StaticDB.user = user;
	}

	public static ArrayList<String> getAreas() {
		return areas;
	}

	public static void setAreas(ArrayList<String> areas) {
		StaticDB.areas = areas;
	}

	public static ArrayList<String> getTags() {
		return tags;
	}

	public static void setTags(ArrayList<String> tags) {
		StaticDB.tags = tags;
	}

	public static ArrayList<String> getFeedbacks() {
		return feedbacks;
	}

	public static void setFeedbacks(ArrayList<String> feedbacks) {
		StaticDB.feedbacks = feedbacks;
	}
	

}
